/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nosqplpj;
import Connection.util.Conn;
import com.mongodb.client.MongoDatabase;
/**
 *
 * @author Sailesh
 */
public class Nosqplpj {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Conn c=new Conn();
        String s="Nosql";
        MongoDatabase database=new Conn().getConnect(s);
        new Login().setVisible(true);
    }
    
}
